
var core = require('web.core');
var QWeb = core.qweb;


